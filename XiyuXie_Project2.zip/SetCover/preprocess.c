


preprocessing()
{



	int single= removeSingleton();

	
	


	int sub= removeSubSetPole();

	
	int sup= removeSupSetMeter();
	
	
	printf("preprocessing I %d , II %d III %d \n", single, sub, sup);	

		
}
