
# Compile
#	cc main.c -lm -o setcover

# Run
#	./setscover M P datafile fn k p
#		k=1 for greedy score1 score2	
# or	
#	./set
#	then type in


# Modify bit.c line (not necessary)
# #define INTSIZE 32 (to 64 )
# for efficiency on 64 bit machine

